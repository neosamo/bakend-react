export enum MemberType {
    USER = 'USER',
    RESTAURANT = 'RESTAURANT',
}

export enum MemberStatus {
   ACTIVE = 'ACTIVE',
   BLOCK = 'BLOCK',
   DELETE = 'DELETE',
}