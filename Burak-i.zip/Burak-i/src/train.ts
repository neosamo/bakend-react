// TASK ZE

// Shunday function yozing, uniygona string parametri mavjud bo'lsin.
// Bu function string tarkibidagi takrorlangan xarflarni olib tashlab qolgan
// qiymatni qaytarsin.

// MASALAN: removeDuplicate('stringg') return 'string'

// Yuqoridagi misolda, 'stringg' so'zi tarkibida 'g' harfi takrorlanmoqda
// funktsiyamiz shu bittadan ortiq takrorlangan harfni olib natijan

function removeDuplicate(str: string): string {
  let result = '';
  for (let char of str) {
      if (!result.includes(char)) {
          result += char;
      }
  }
  return result;
}

console.log(removeDuplicate('stringg')); 



// //  Task ZD 



// function changeNumberInArray(firstNum: number, arr: number[], thirdNum: number): number[] {
//   const index = firstNum;

//   if (index < arr.length) {
//       arr[index] = thirdNum;
//   }
//   console.log(arr);
//   return arr;
// }
// changeNumberInArray(1, [1, 3, 7, 2], 2) // [1, 2, 7, 2]



// TASK zc 
// function celsiusToFahrenheit(celsius: number): number {
//   const res = (celsius * 9 / 5) + 32
//   console.log(`${celsius} Celcius equals to : ${res} Fherente`)
//   return res;
// }

// celsiusToFahrenheit(5) ;




// task ZB

// function randomBetween(min: number, max: number): number {
//   const randomNum = Math.floor(Math.random() * (max - min + 1)) + min;
//   console.log(`Generated random number between ${min} and ${max}: ${randomNum}`);
//   return randomNum;
// }
// randomBetween(30, 50);
// // TASK ZA

// Shunday function yozing, u array ichidagi objectlarni
// 'age' qiymati bo'yicha sortlab bersin.
// MASALAN: sortByAge([{age:23}, {age:21}, {age:13}]) return [{age:13}, {age:21}, {agenp:23}]


// Yuqoridagi misolda, kichik raqamlar katta raqamlar tomon
// tartiblangan holatda return bo'lmoqda.


// function sortByAge(arr: { age: number }[]): { age: number }[] {
//   arr.sort((a, b) => a.age - b.age);
//   console.log(arr);
//   return arr;
// }

// sortByAge([{age:23}, {age:21}, {age:13}]) 

// task -Z


// function sumEvens(arr: number[]): number {
//   return arr
//     .filter(num => num % 2 === 0)
//     .reduce((sum, num) => sum + num, 0);
// }

// console.log(sumEvens([1, 2, 3])); // 2
// console.log(sumEvens([1, 2, 3, 2])); // 4

// // task Y 

// function findIntersection(arr1: number[], arr2: number[]): number[] {
//   const intersection = arr1.filter(value => arr2.includes(value));

//   return Array.from(new Set(intersection));
// }

// const result = findIntersection([1, 2, 3], [3, 2, 0]);
// console.log(result); // [2, 3]


// let tom = (73+73)/60;
// console.log(tom);
// function countOccurrences(obj: any, key: string): number {
//   let count = 0;

//   function recurse(currentObj: any) {
//     for (const k in currentObj) {
//       if (k === key) {
//         count++;
//       }
//       if (typeof currentObj[k] === 'object' && currentObj[k] !== null) {
//         recurse(currentObj[k]);
//       }
//     }
//   }

//   recurse(obj);
//   return count;
// }

// countOccurrences(
//   { model: 'Bugatti', steer: { model: 'HANKOOK', size: 30 } },
//   'model'
// );

/*
Task W: Chunk Array
function chunkArray(arr: any[], size: number): any[][] {
  let result: any[][] = [];

  for (let i = 0; i < arr.length; i += size) {
    result.push(arr.slice(i, i + size));
  }

  return result;
}

const result = chunkArray([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 3);
console.log(result);
*/

/* MIT Task: Count Characters
function countChars(str: string): { [key: string]: number } {
  const charCount: { [key: string]: number } = {};

  for (const char of str) {
    charCount[char] = (charCount[char] || 0) + 1;
  }

  return charCount;
}

console.log(countChars("typescript"));
*/

/* Task U: Sum of Odd Numbers
function sumOdds(userInp: number): number {
  let sum = 0;
  for (let i = 1; i <= userInp; i++) {
    if (i % 2 !== 0) {
      sum++;
    }
  }
  return sum;
}

console.log(sumOdds(9));   // Output: 5
console.log(sumOdds(11));  // Output: 6
*/

/* Missing Number Task
function missingNumber(nums: number[]): number {
  const n: number = nums.length;

  for (let i = 0; i <= n; i++) {
    if (!nums.includes(i)) {
      return i;
    }
  }

  return -1;
}

console.log(missingNumber([3, 0, 1]));
*/

/* Task R: Simple Calculator
function calculate(str: string): number | null {
  const result = str.split(' ');
  const num1 = Number(result[0]);
  const operator = result[1];
  const num2 = Number(result[2]);

  switch (operator) {
    case '+':
      return num1 + num2;
    case '-':
      return num1 - num2;
    case '*':
      return num1 * num2;
    case '/':
      return num1 / num2;
    default:
      console.log('Unsupported operator');
      return null;
  }
}

console.log(calculate("2 * 5"));  // Output: 10
*/

/* Task Q: Check if Object has a Property
function hasProperty(input: object, word: string): boolean {
  return input.hasOwnProperty(word);
}

console.log(hasProperty({ name: "BMW", model: "M3" }, "model"));  // true
console.log(hasProperty({ name: "BMW", model: "M3" }, "year"));   // false
*/

/* Task P: Convert Object to Array
function objectToArray(input: Record<string, any>): any[][] {
  const newArray: any[][] = [];

  for (const key in input) {
    if (input.hasOwnProperty(key)) {
      newArray.push([key, input[key]]);
    }
  }

  return newArray;
}

const result = objectToArray({ a: 10, b: 20 });
console.log(result);  // Output: [['a', 10], ['b', 20]]
*/

/* Task O: Sum of Numbers in an Array
function calculateSumOfNumbers(arr: any[]): number {
  let sum = 0;
  for (let i = 0; i < arr.length; i++) {
    if (typeof arr[i] === 'number') {
      sum += arr[i];
    }
  }
  return sum;
}

console.log(calculateSumOfNumbers([12, "sss", 22]));  // Output: 34
*/

/* MIT Task N: Palindrome Check
function palindromeCheck(word: string): boolean {
  const lowerCaseWord = word.toLowerCase();
  const reversedWord = lowerCaseWord.split('').reverse().join('');
  return lowerCaseWord === reversedWord;
}

console.log(palindromeCheck("dad"));  // true
console.log(palindromeCheck("son"));  // false
*/

/* MIT Task M: Get Square Numbers
function getSquareNumbers(numbers: number[]): { number: number; square: number }[] {
  return numbers.map(num => ({
    number: num,
    square: num * num,
  }));
}

console.log(getSquareNumbers([1, 2, 3]));
*/

/* MIT Task: Reverse Words in a Sentence
function reverseSentence(sentence: string): string {
  return sentence
    .split(' ')
    .map(word => word.split('').reverse().join(''))
    .join(' ');
}

console.log(reverseSentence("ew ekil !gnidoc os hcum"));  // Output: "we like coding so much"
*/

/* MIT Task K: Count Vowels
function countVowels(str: string): number {
  const vowels = 'aeiouAEIOU';
  let count = 0;

  for (let i = 0; i < str.length; i++) {
    if (vowels.includes(str[i])) {
      count++;
    }
  }

  return count;
}

console.log(countVowels("Go'zal olam"));  // Output: 5
*/

/* Task I: Majority Element
function majorityElement(arr: number[]): number | null {
  if (arr.length === 0) return null;

  const frequency: { [key: number]: number } = {};
  for (const num of arr) {
    frequency[num] = (frequency[num] || 0) + 1;
  }

  let maxCount = 0;
  let majorityElem = null;

  for (const num in frequency) {
    if (frequency[num] > maxCount) {
      maxCount = frequency[num];
      majorityElem = Number(num);
    }
  }

  return majorityElem;
}

console.log(majorityElement([1, 2, 3, 4, 5, 4, 3, 4]));  // Output: 4
*/

/* Task G: Get Highest Index
function getHighestIndex(intList: number[]): number {
  let maxNum = intList[0];
  let maxIndex = 0;

  for (let i = 1; i < intList.length; i++) {
    if (intList[i] > maxNum) {
      maxNum = intList[i];
      maxIndex = i;
    }
  }

  return maxIndex;
}

console.log(getHighestIndex([5, 21, 12, 21, 8]));  // Output: 1
*/

/* Task H: Get Positive Numbers as String
function getPositive(intList: number[]): string {
  return intList.filter(num => num > 0).join('');
}

console.log(getPositive([1, -4, 2]));  // Output: "12"
*/

/* Task H2: Get Digits from String
function getDigits(input: string): string {
  return input.replace(/\D/g, '');
}

console.log(getDigits("m14i1t"));  // Output: "141"
*/
